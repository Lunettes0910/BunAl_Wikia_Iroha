﻿function link(url) {
    return ("<a href=\"" + url + "\">" + url + "</a>");
}
function llink(url, text) {
    return ("<a href=\"" + url + "\">" + text + "</a>");
}
function br(text) {
    return ("\n<br>" + text);
}
function b(text) {
    return ("\n\n<br><br><b>" + text + "</b>");
}
function p(text) {
    return ("\n<b style=\"font-size: larger;\">" + text + "</b>");
}